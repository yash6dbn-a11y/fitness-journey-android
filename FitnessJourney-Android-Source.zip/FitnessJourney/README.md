# Fitness Journey for Samsung

A native Android starter app with a dark, premium fitness dashboard and a compact horizontal home-screen widget.

## Confirmed starting values
- Starting weight: 101.4 kg
- Current weight: 94.55 kg
- Target weight: 76 kg
- Lost: 6.85 kg
- Remaining: 18.55 kg
- Progress: 26.8% (shown rounded to 27%)

## Included
- Jetpack Compose dashboard and history screen
- Manual Sunday weigh-in entry
- Local weight history stored on-device with SharedPreferences
- Android home-screen App Widget, tappable to open the app
- Widget refresh immediately after saving a weigh-in
- No account or cloud sync

## Build
Open this folder in Android Studio (recent stable version), allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. Install the generated debug APK on your Samsung phone. Add the widget by long-pressing the home screen, choosing **Widgets > Fitness Journey > Fitness Progress**, and resizing it to 4 columns by 1 row if your launcher allows.

## Notes
- This is a source project, not a prebuilt APK. It needs Android Studio / Android SDK to compile and sign.
- The widget is designed as a wide, short 4-column-style widget. Actual sizing depends on One UI launcher grid and screen settings.
- The first version uses manual weigh-ins. The app does not read Samsung Health data.
- A Sunday reminder notification and automated backup/sync are not included in this first build.
